import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author shullander
 */
public class HandAnalyzer
{
	ArrayList<Card> DetailedHand = new ArrayList<Card>();
	ArrayList<String> hand = new ArrayList<String>();
	int handTotal = 0;

    public HandAnalyzer(ArrayList<String> hand)
    {
		for(int i=0; i<=hand.size()-1;i++)
		{
			this.hand.add(hand.get(i));
		}
    }        

    // get details about each card
    public void CreateDetailedHand()
    {

    		if(hand.get(0).charAt(0) == '2')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 2;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 2;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 2;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 2;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 3s of all suits
    		else if(hand.get(0).charAt(0) == '3')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 3;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 3;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 3;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 3;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 4s of all suits
    		else if(hand.get(0).charAt(0) == '4')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 4;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 4;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 4;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 4;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 5s of all suits
    		else if(hand.get(0).charAt(0) == '5')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 5;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 5;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 5;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 5;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 6s of all suits
    		else if(hand.get(0).charAt(0) == '6')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 6;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 6;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 6;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 6;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 7s of all suits
    		else if(hand.get(0).charAt(0) == '7')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 7;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 7;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 7;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 7;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 8s of all suits
    		else if(hand.get(0).charAt(0) == '8')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 8;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 8;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 8;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 8;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 9s of all suits
    		else if(hand.get(0).charAt(0) == '9')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 9;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 9;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 9;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 9;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for 10s of all suits
    		else if(hand.get(0).charAt(0) == '1')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 10;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 10;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 10;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 10;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for Jacks of all suits
    		else if(hand.get(0).charAt(0) == 'J')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 11;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 11;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 11;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 11;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for Queens of all suits
    		else if(hand.get(0).charAt(0) == 'Q')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 12;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 12;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 12;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 12;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for Kings of all suits
    		else if(hand.get(0).charAt(0) == 'K')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 13;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 13;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 13;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 13;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		// checking for Aces of all suits
    		else if(hand.get(0).charAt(0) == 'A')
    		{
    			if(hand.get(0).charAt(hand.get(0).length()-1) == 'H')
    			{
    				Card newCard = new Card();
    			    newCard.value = 1;
    			    newCard.suit = "Heart";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'S')
    			{
    				Card newCard = new Card();
    			    newCard.value = 1;
    			    newCard.suit = "Spade";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'D')
    			{
    				Card newCard = new Card();
    			    newCard.value = 1;
    			    newCard.suit = "Diamond";
    			    DetailedHand.add(newCard);
    			}
    			else if(hand.get(0).charAt(hand.get(0).length()-1) == 'C')
    			{
    				Card newCard = new Card();
    			    newCard.value = 1;
    			    newCard.suit = "Clover";
    			    DetailedHand.add(newCard);
    			}
    		}
    		
    		if(hand.get(1).charAt(0) == '2')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 2;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 2;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 2;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 2;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 3s of all suits
    		else if(hand.get(1).charAt(0) == '3')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 3;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 3;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 3;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 3;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 4s of all suits
    		else if(hand.get(1).charAt(0) == '4')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 4;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 4;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 4;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 4;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 5s of all suits
    		else if(hand.get(1).charAt(0) == '5')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 5;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 5;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 5;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 5;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 6s of all suits
    		else if(hand.get(1).charAt(0) == '6')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 6;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 6;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 6;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 6;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 7s of all suits
    		else if(hand.get(1).charAt(0) == '7')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 7;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 7;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 7;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 7;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 8s of all suits
    		else if(hand.get(1).charAt(0) == '8')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 8;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 8;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 8;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 8;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 9s of all suits
    		else if(hand.get(1).charAt(0) == '9')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 9;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 9;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 9;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 9;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for 10s of all suits
    		else if(hand.get(1).charAt(0) == '1')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 10;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 10;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 10;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 10;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for Jacks of all suits
    		else if(hand.get(1).charAt(0) == 'J')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 11;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 11;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 11;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 11;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for Queens of all suits
    		else if(hand.get(1).charAt(0) == 'Q')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 12;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 12;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 12;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 12;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for Kings of all suits
    		else if(hand.get(1).charAt(0) == 'K')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 13;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 13;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 13;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 13;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}
    		
    		// checking for Aces of all suits
    		else if(hand.get(1).charAt(0) == 'A')
    		{
    			if(hand.get(1).charAt(hand.get(1).length()-1) == 'H')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 1;
    			    newCard2.suit = "Heart";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'S')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 1;
    			    newCard2.suit = "Spade";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'D')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 1;
    			    newCard2.suit = "Diamond";
    			    DetailedHand.add(newCard2);
    			}
    			else if(hand.get(1).charAt(hand.get(1).length()-1) == 'C')
    			{
    				Card newCard2 = new Card();
    			    newCard2.value = 1;
    			    newCard2.suit = "Clover";
    			    DetailedHand.add(newCard2);
    			}
    		}

    		
    		if(hand.get(2).charAt(0) == '2')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 2;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 2;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 2;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 2;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 3s of all suits
    		else if(hand.get(2).charAt(0) == '3')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 3;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 3;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 3;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 3;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 4s of all suits
    		else if(hand.get(2).charAt(0) == '4')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 4;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 4;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 4;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 4;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 5s of all suits
    		else if(hand.get(2).charAt(0) == '5')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 5;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 5;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 5;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 5;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 6s of all suits
    		else if(hand.get(2).charAt(0) == '6')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 6;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 6;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 6;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 6;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 7s of all suits
    		else if(hand.get(2).charAt(0) == '7')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 7;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 7;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 7;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 7;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 8s of all suits
    		else if(hand.get(2).charAt(0) == '8')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 8;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 8;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 8;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 8;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 9s of all suits
    		else if(hand.get(2).charAt(0) == '9')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 9;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 9;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 9;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 9;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for 10s of all suits
    		else if(hand.get(2).charAt(0) == '1')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 10;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 10;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 10;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 10;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for Jacks of all suits
    		else if(hand.get(2).charAt(0) == 'J')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 11;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 11;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 11;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 11;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for Queens of all suits
    		else if(hand.get(2).charAt(0) == 'Q')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 12;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 12;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 12;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 12;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for Kings of all suits
    		else if(hand.get(2).charAt(0) == 'K')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 13;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 13;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 13;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 13;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}
    		
    		// checking for Aces of all suits
    		else if(hand.get(2).charAt(0) == 'A')
    		{
    			if(hand.get(2).charAt(hand.get(2).length()-1) == 'H')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 1;
    			    newCard3.suit = "Heart";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'S')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 1;
    			    newCard3.suit = "Spade";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'D')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 1;
    			    newCard3.suit = "Diamond";
    			    DetailedHand.add(newCard3);
    			}
    			else if(hand.get(2).charAt(hand.get(2).length()-1) == 'C')
    			{
    				Card newCard3 = new Card();
    			    newCard3.value = 1;
    			    newCard3.suit = "Clover";
    			    DetailedHand.add(newCard3);
    			}
    		}

    		
    		
    		if(hand.get(3).charAt(0) == '2')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 2;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 2;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 2;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 2;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 3s of all suits
    		else if(hand.get(3).charAt(0) == '3')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 3;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 3;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 3;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 3;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 4s of all suits
    		else if(hand.get(3).charAt(0) == '4')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 4;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 4;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 4;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 4;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 5s of all suits
    		else if(hand.get(3).charAt(0) == '5')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 5;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 5;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 5;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 5;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 6s of all suits
    		else if(hand.get(3).charAt(0) == '6')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 6;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 6;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 6;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 6;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 7s of all suits
    		else if(hand.get(3).charAt(0) == '7')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 7;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 7;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 7;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 7;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 8s of all suits
    		else if(hand.get(3).charAt(0) == '8')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 8;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 8;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 8;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 8;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 9s of all suits
    		else if(hand.get(3).charAt(0) == '9')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 9;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 9;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 9;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 9;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for 10s of all suits
    		else if(hand.get(3).charAt(0) == '1')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 10;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 10;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 10;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 10;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for Jacks of all suits
    		else if(hand.get(3).charAt(0) == 'J')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 11;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 11;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 11;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 11;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for Queens of all suits
    		else if(hand.get(3).charAt(0) == 'Q')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 12;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 12;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 12;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 12;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for Kings of all suits
    		else if(hand.get(3).charAt(0) == 'K')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 13;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 13;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 13;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 13;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}
    		
    		// checking for Aces of all suits
    		else if(hand.get(3).charAt(0) == 'A')
    		{
    			if(hand.get(3).charAt(hand.get(3).length()-1) == 'H')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 1;
    			    newCard4.suit = "Heart";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'S')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 1;
    			    newCard4.suit = "Spade";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'D')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 1;
    			    newCard4.suit = "Diamond";
    			    DetailedHand.add(newCard4);
    			}
    			else if(hand.get(3).charAt(hand.get(3).length()-1) == 'C')
    			{
    				Card newCard4 = new Card();
    			    newCard4.value = 1;
    			    newCard4.suit = "Clover";
    			    DetailedHand.add(newCard4);
    			}
    		}

    		
    		
    		if(hand.get(4).charAt(0) == '2')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 2;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 2;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 2;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 2;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 3s of all suits
    		else if(hand.get(4).charAt(0) == '3')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 3;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 3;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 3;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 3;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 4s of all suits
    		else if(hand.get(4).charAt(0) == '4')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 4;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 4;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 4;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 4;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 5s of all suits
    		else if(hand.get(4).charAt(0) == '5')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 5;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 5;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 5;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 5;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 6s of all suits
    		else if(hand.get(4).charAt(0) == '6')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 6;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 6;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 6;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 6;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 7s of all suits
    		else if(hand.get(4).charAt(0) == '7')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 7;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 7;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 7;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 7;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 8s of all suits
    		else if(hand.get(4).charAt(0) == '8')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 8;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 8;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 8;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 8;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 9s of all suits
    		else if(hand.get(4).charAt(0) == '9')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 9;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 9;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 9;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 9;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for 10s of all suits
    		else if(hand.get(4).charAt(0) == '1')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 10;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 10;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 10;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 10;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for Jacks of all suits
    		else if(hand.get(4).charAt(0) == 'J')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 11;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 11;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 11;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 11;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for Queens of all suits
    		else if(hand.get(4).charAt(0) == 'Q')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 12;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 12;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 12;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 12;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for Kings of all suits
    		else if(hand.get(4).charAt(0) == 'K')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 13;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 13;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 13;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 13;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    		
    		// checking for Aces of all suits
    		else if(hand.get(4).charAt(0) == 'A')
    		{
    			if(hand.get(4).charAt(hand.get(4).length()-1) == 'H')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 14;
    			    newCard5.suit = "Heart";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'S')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 14;
    			    newCard5.suit = "Spade";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'D')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 14;
    			    newCard5.suit = "Diamond";
    			    DetailedHand.add(newCard5);
    			}
    			else if(hand.get(4).charAt(hand.get(4).length()-1) == 'C')
    			{
    				Card newCard5 = new Card();
    			    newCard5.value = 14;
    			    newCard5.suit = "Clover";
    			    DetailedHand.add(newCard5);
    			}
    		}
    }
    
    public void sortByRank()
    {
    	Collections.sort(DetailedHand, Comparator.comparing(Card::getRank));

    }
    
    public void sortBySuit()
    {
    	Collections.sort(DetailedHand, Comparator.comparing(Card::getSuit));
    }
    
    public int evalHand()
    {
        // Start of Royal and Straight Flush
        sortBySuit();
        if (DetailedHand.get(0).getSuit().equals(DetailedHand.get(4).getSuit()))
        {
        	sortByRank();
        	// Start of Royal Flush
        	if(DetailedHand.get(0).getRank() == 10 && DetailedHand.get(1).getRank() == 11 && DetailedHand.get(2).getRank() == 12 && DetailedHand.get(3).getRank() == 13 && DetailedHand.get(4).getRank() == 14)
        	{
        		handTotal = 9000; // split pot if tie
        		return handTotal;
        	} // End of Royal Flush
        	
        	
        	// Start of Straight Flush
        	else if(DetailedHand.get(0).getRank()+1 == DetailedHand.get(1).getRank() && DetailedHand.get(1).getRank()+1 == DetailedHand.get(2).getRank() && DetailedHand.get(2).getRank()+1 == DetailedHand.get(3).getRank() && DetailedHand.get(3).getRank()+1 == DetailedHand.get(4).getRank())
        	{
        			handTotal = 8000 + DetailedHand.get(4).getRank(); // Straight flush tie goes to highest card in straight
        			return handTotal;
        	} 
        	// In the case of if A,2,3,4,5
    		else if(DetailedHand.get(0).getRank()+1 == DetailedHand.get(1).getRank() && DetailedHand.get(1).getRank()+1 == DetailedHand.get(2).getRank() && DetailedHand.get(2).getRank()+1 == DetailedHand.get(3).getRank() && DetailedHand.get(4).getRank()-12 == DetailedHand.get(0).getRank())
        	{
        		{
        			handTotal = 8005; // Here, the high card is 5
        			return handTotal;
        		}
        	}// End of Straight Flush
        } // End of Royal and Straight Flush
        
        
        // Start of Four of a Kind
        sortByRank();
        if (DetailedHand.get(0).getRank() == DetailedHand.get(3).getRank() || DetailedHand.get(1).getRank() == DetailedHand.get(4).getRank())
        {
           handTotal = 7000 + DetailedHand.get(2).getRank()*4; // 3rd card must be part of this hand, tie will check 5th card
           return handTotal;
        } // End of Four of a Kind
        
        
        // Start of Full House
        // Already sorted by rank from last test case
        if (DetailedHand.get(0).getRank() == DetailedHand.get(2).getRank() && DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
        {
            handTotal = 6000 + DetailedHand.get(2).getRank(); // highest three of a kind wins, pair is checked if tied
            return handTotal;
        }
        else if (DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() && DetailedHand.get(2).getRank() == DetailedHand.get(4).getRank())
        {
            handTotal = 6000 + DetailedHand.get(2).getRank(); // same return but split for visibility purposes
            return handTotal;
        } // End of Full House
        
        
        // Start of Flush
        sortBySuit();
        if (DetailedHand.get(0).getSuit().equals(DetailedHand.get(4).getSuit()))
        {
        	sortByRank();
        	handTotal = 5000 + DetailedHand.get(4).getRank(); // High card wins if two flushes
        	return handTotal;
        } //End of Flush
        
        
        // Start of Straight
        sortByRank();
        if(DetailedHand.get(0).getRank()+1 == DetailedHand.get(1).getRank() && DetailedHand.get(1).getRank()+1 == DetailedHand.get(2).getRank() && DetailedHand.get(2).getRank()+1 == DetailedHand.get(3).getRank() && DetailedHand.get(3).getRank()+1 == DetailedHand.get(4).getRank())
    	{
    			handTotal = 4000 + DetailedHand.get(4).getRank(); // Straight tie goes to highest card in straight
    			return handTotal;
    	} 
    	// In the case of if A,2,3,4,5
		else if(DetailedHand.get(0).getRank()+1 == DetailedHand.get(1).getRank() && DetailedHand.get(1).getRank()+1 == DetailedHand.get(2).getRank() && DetailedHand.get(2).getRank()+1 == DetailedHand.get(3).getRank() && DetailedHand.get(4).getRank()-12 == DetailedHand.get(0).getRank())
    	{
    		{
    			handTotal = 4005; // Here, the high card is 5
    			return handTotal;
    		}
    	} // End of Straight
        
        
        // Start of Two Pairs
        // Already sorted by rank from last test case
        if((DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() && (DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank() || DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())) || (DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank() && DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank()))
        {
        	handTotal = 3000 + DetailedHand.get(3).getRank(); // 4th card will always be highest pair card, other pair tested for tie then remaining high card
        	return handTotal;
        } //End of Two Pairs
        
        
        // Start of Pair
        // Already sorted by rank from last test case
        if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() || DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank())
        {
        	handTotal = 2000 + DetailedHand.get(1).getRank(); // Check high card, then next highest and so on for tie
            return handTotal;
        }
        if(DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank() || DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
        {
        	handTotal = 2000 + DetailedHand.get(3).getRank(); // Check high card, then next highest and so on for tie
            return handTotal;
        }//End of Pair
        
        // Start of High Card
        // Already sorted by rank from last test case
        handTotal = 1000 + DetailedHand.get(4).getRank(); // remaining high cards tested if tie;
        return handTotal;
    }
    
    public int evaluateTies(int tiedValue, int counter)
    {
    	int newTotal = tiedValue;
    	int count = counter;
    	int inputValue = tiedValue;
    	
    	// this are automatically a tie because no other cards to check
    	if(inputValue > 8000 || (inputValue >= 4000 && inputValue < 6000))
    	{
    		newTotal = 0;
    		return newTotal;
    	} // End of automatic
    	
    	
		// 4ofkind - check the card that is different
    	if(inputValue >= 7000 && inputValue < 8000)
    	{
    		
    		if(count == 0)
    		{
    			sortByRank();
    			if(DetailedHand.get(0).getRank() == DetailedHand.get(3).getRank())
    			{
    				newTotal = 7000 + DetailedHand.get(4).getRank();
    				return newTotal;
    			}
    			else
    			{
    				newTotal = 7000 + DetailedHand.get(0).getRank();
    				return newTotal;
    			}
    		}
    		if(count > 0)
    		{
    			newTotal = 0;
    			return newTotal;
    		}
    	} // End of 4ofkind
    	
    	
    	// full house  - check for highest pair
    	if(inputValue >= 6000 && inputValue < 7000)
    	{
    		if(count == 0)
    		{
    			sortByRank();
    			if (DetailedHand.get(0).getRank() == DetailedHand.get(2).getRank() && DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
    	        {
    	            newTotal = 6000 + DetailedHand.get(3).getRank(); // highest three of a kind wins, pair is checked if tied
    	            return newTotal;
    	        }
    	        else if (DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() && DetailedHand.get(2).getRank() == DetailedHand.get(4).getRank())
    	        {
    	            newTotal = 6000 + DetailedHand.get(1).getRank(); // same return but split for visibility purposes
    	            return newTotal;
    	        } // End of Full House
    		}
    		if(count > 0)
    		{
    			newTotal = 0;
    			return newTotal;
    		}
    		
    	} // End full house 
    	
    	
    	// Two Pair - check other pair then the 5th card
    	if(inputValue >= 3000 && inputValue < 4000)
    	{
    		if(count == 0)
    		{
    				sortByRank();
    				newTotal = 3000 + DetailedHand.get(1).getRank(); // lowest pair will always have one card here
    				return newTotal;
    		}
    		
    		if(count == 1)
    		{
    				sortByRank();
    				if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() && DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank())
    				{
    					newTotal = 3000 + DetailedHand.get(4).getRank();
        				return newTotal;
    				}
    				else if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() && DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
    				{
    					newTotal = 3000 + DetailedHand.get(2).getRank();
        				return newTotal;
    				}
    				else if(DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank() && DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
    				{
    					newTotal = 3000 + DetailedHand.get(0).getRank();
        				return newTotal;
    				}
    		}
    		
    		if(count > 1)
    		{
    			newTotal = 0;
    			return newTotal;
    		}
    	} // End of two pair
    	
    	
    	// Pair - check highest of kickers then next highest then lowest
    	if(inputValue >= 2000 && inputValue < 3000)
    	{
    		if(count == 0)
    		{
    			sortByRank();
    			if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() || DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank() || DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank())
    			{
    				newTotal = 2000 + DetailedHand.get(4).getRank();
    				return newTotal;
    			}
    			else
    			{
    				newTotal = 2000 + DetailedHand.get(3).getRank();
    				return newTotal;
    			}
    		}
    		
    		if(count == 1)
    		{
    			sortByRank();
    			if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank() || DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank())
    			{
    				newTotal = 2000 + DetailedHand.get(3).getRank();
    				return newTotal;
    			}
    			else if(DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank() || DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
    			{
    				newTotal = 2000 + DetailedHand.get(1).getRank();
    				return newTotal;
    			}
    		}
    		
    		if(count == 2)
    		{
    			sortByRank();
    			if(DetailedHand.get(0).getRank() == DetailedHand.get(1).getRank())
    			{
    				newTotal = 2000 + DetailedHand.get(2).getRank();
    				return newTotal;
    			}
    			else if(DetailedHand.get(1).getRank() == DetailedHand.get(2).getRank() || DetailedHand.get(2).getRank() == DetailedHand.get(3).getRank() || DetailedHand.get(3).getRank() == DetailedHand.get(4).getRank())
    			{
    				newTotal = 2000 + DetailedHand.get(0).getRank();
    				return newTotal;
    			}
    		}
    		
    		if(count > 2)
    		{
    			newTotal = 0;
    			return newTotal;
    		}
    		
    	} // End of pair
    	
    	
    	// High Card - check next highest then next then next then next
    	if(inputValue >= 1000 && inputValue < 2000)
    	{
    		if(count == 0)
    		{
    			sortByRank();
    			newTotal = 1000 + DetailedHand.get(3).getRank();
    			return newTotal;
    		}
    		
    		if(count == 1)
    		{
    			sortByRank();
    			newTotal = 1000 + DetailedHand.get(2).getRank();
    			return newTotal;
    		}
    		
    		if(count == 2)
    		{
    			sortByRank();
    			newTotal = 1000 + DetailedHand.get(1).getRank();
    			return newTotal;
    		}
    		
    		if(count == 3)
    		{
    			sortByRank();
    			newTotal = 1000 + DetailedHand.get(0).getRank();
    			return newTotal;
    		}
    		
    		if(count > 3)
    		{
    			newTotal = 0;
    			return newTotal;
    		}
    	} // End of high card
    	
    	return newTotal;
    }	
}
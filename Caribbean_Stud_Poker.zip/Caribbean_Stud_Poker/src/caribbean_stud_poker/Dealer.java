package caribbean_stud_poker;

/**
 *
 * @author Jeremy Roland
 */
public class Dealer 
{
    private int money;
    //create a dealer object to represent the dealer in the game 
    public Dealer(int m)
    {
        money = m; 
    }
    public int getMoney()
    {
        return money;
    }
        public void setMoney(int m)
    {
        money = m;
    }
}

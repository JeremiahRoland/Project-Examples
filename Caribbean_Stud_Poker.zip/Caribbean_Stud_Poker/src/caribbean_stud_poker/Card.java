


/**
 *
 * @author shullander and donna
 */


public class Card {
	 int value;
	 String suit;


//Get suit
public String getSuit()
{
 return suit;
}

//Get rank
public int getRank()
 {
     return value;
 }

}
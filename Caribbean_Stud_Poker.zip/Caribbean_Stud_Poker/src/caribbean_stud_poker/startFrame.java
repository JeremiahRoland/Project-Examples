import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.*;
/**
 * This is the starting frame, which acts as a main menu
 *
 * @author Jeremiah Roland
 */
public class startFrame
{
    /**
     * Create a constructor to make the start frame
     * This will be the first frame displayed when the game starts, and will be displayed when the game is closed out
     * Constructs a new frame that is initially invisible 
     * Throws a HeadlessException
     * Idea: Display a button that starts our group's card game (Caribbean Stud Poker)
     * This way, other card games could be implemented using the same style, and have a button to launch them 
     */
    public startFrame() throws HeadlessException
    {
        
    }
    /**
     * A run() method to run the start frame when game first starts
     * Is called by other frames when the close game button is clicked
     */
    public void run()
    {
        //create the frame 
        JFrame startFrame = new JFrame("Starg Page");
        
        //create a button to launch our team's game 
        JButton cspLaunch = new JButton("Caribbean Stud Poker"); 
        
        //create a button for player to view their wins/losses
        JButton winLoss = new JButton("CSP Player Stats");
        
        //create another button to close the game entirely 
        JButton cancel = new JButton("Close the Program"); 
        
        //create a button to turn sound on/off 
        JButton sound = new JButton("Sound On/Off");
        
        
        //set the text size and font of the buttons to something easier to read
        cspLaunch.setFont(new Font("Arial", Font.PLAIN, 35));
        cancel.setFont(new Font("Arial", Font.PLAIN, 35)); 
        winLoss.setFont(new Font("Arial", Font.PLAIN, 35));
        sound.setFont(new Font("Arial", Font.PLAIN, 35));

        
        /**
         * When the close program button is clicked, have the program closed 
         * Do this by adding an action listener and using an anonymous class to 
         * implement the ActionListener interface 
         * Have the method actionPerformed() called and set what needs to be done 
         * in the method. 
         * @param the implicit parameter of this type of call is the button it 
         * is associated with 
         */
        cancel.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                startFrame.dispose(); 
            }
        });
        /**
         * When the winLoss button is clicked, read into info from a file 
         * Have the method actionPerformed() called and set what needs to be done 
         * in the method
         * @param the implicit parameter of this type of call is the button it 
         * is associated with 
         */
        winLoss.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent stats)
            {
                //create a file
                File winLog = new File("playerWins.txt");

                //check if there is a file for player wins
                //if there is, then read off the player's wins
                //if not, then say there's no wins 
                if(winLog.exists() == true)
                {
                    System.out.println("playerWins file found");
                    int playerWins = 0; 
                    //read in the number from the file "playerWins" 
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */

                        FileReader winReader = new FileReader("playerWins.txt");
                        BufferedReader bufReader1 = new BufferedReader(winReader);
                        String line1;
                        /**
                         * A while loop for reading each line of text in the file myClasses.txt
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isn't empty (or null).
                         */
                        while((line1 = bufReader1.readLine()) != null)
                        {
                            playerWins = Integer.parseInt(line1);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader1.close();
                        JOptionPane.showMessageDialog(startFrame, "Ye have won " + playerWins + " games", "Victories!",
                        JOptionPane.INFORMATION_MESSAGE);
                        //System.out.println("You have won " + playerWins + " games");
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the exception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                else
                {
                    System.out.println("You haven't played any games of Caribbean Stud Poker");
                }

                //create a file for losses 
                File lossLog = new File("playerLosses.txt"); 

                //check if there is a file for player losses 
                //if there is, then read off the player's losses 
                //if not, then say there's no losses 
                if(lossLog.exists())
                {
                    System.out.println("playerLoss file found"); 
                    int playerLosses = 0; 
                    //read in the number from the file "playerWins" 
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */

                        FileReader lossReader = new FileReader("playerLosses.txt");
                        BufferedReader bufReader2 = new BufferedReader(lossReader);
                        String line2;
                        /**
                         * A while loop for reading each line of text in the file myClasses.txt
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isn't empty (or null).
                         */
                        while((line2 = bufReader2.readLine()) != null)
                        {
                            playerLosses = Integer.parseInt(line2);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader2.close();
                        JOptionPane.showMessageDialog(startFrame, "Ye have lost " + playerLosses + " games", "Defeats!", 
                        JOptionPane.INFORMATION_MESSAGE);
                        //System.out.println("You have lost " + playerLosses + " games");
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the exception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                else
                {
                    System.out.println("You haven't played any games of Caribbean Stud Poker");
                }
            }
        });
        /**
         * When the button for a particular game is clicked, have the program load 
         * another frame for the particular game.
         * Add an action listener and use an anonymous class to implement the
         * ActionListener interface.
         * Have the method actionPerformed() called and set what needs happen.
         * @param the implicit parameter of this type of call is the button it is
         * associated with 
         */
        cspLaunch.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent start)
            {
                //launch the frame with the actual game here
                CSP_Game gameStart = new CSP_Game();
                gameStart.run(90, 90, 0);
                startFrame.dispose(); 
            }
        });
        /**
         * When the sound button is pressed, give the user the option to turn sound on or off. 
         * implement the ActionListener interface 
         * Have the method actionPerformed() called and set what needs to be done 
         * in the method
         * @param the implicit parameter of this type of call is the button it 
         * is associated with 
         */
        sound.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                int soundChange = JOptionPane.showConfirmDialog(null, 
                    "Do you want sound on?", "Sound Settings", JOptionPane.YES_NO_OPTION);
                if(soundChange == JOptionPane.YES_OPTION)
                {
                    JOptionPane.showMessageDialog(startFrame, "Sound functionality coming in later iteration", "Feature Not Ready",
                        JOptionPane.INFORMATION_MESSAGE);
                    //System.out.println("Sound functionality coming in later iteration");
                }
                else if(soundChange == JOptionPane.NO_OPTION)
                {
                    JOptionPane.showMessageDialog(startFrame, "Sound functionality coming in later iteration", "Feature Not Ready",
                        JOptionPane.INFORMATION_MESSAGE);
                    //System.out.println("Sound functionality coming in later iteration");
                }
            }
        });
        
        /**
         * Set the layout of the frame, then add each part of the frame (buttons, etc.)
         */
        startFrame.setLayout(new FlowLayout());
        
        startFrame.add(cspLaunch);
        startFrame.add(winLoss);
        startFrame.add(cancel); 
        startFrame.add(sound);
        
        /**
         * @method setDefaultClosOperation(), used to close the program
         * if the window of the program is closed, thus avoiding the program 
         * continuing to run after user closes the window
         * use the pack() to set the size of the frame to fit all of its contents 
         * then, set the frame to visible 
         */
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.pack();
        startFrame.setVisible(true); 
    }
}

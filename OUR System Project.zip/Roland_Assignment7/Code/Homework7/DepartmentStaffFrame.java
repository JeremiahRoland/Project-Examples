import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.*; 
/**
 * A frame for Department staff, allowing staff to:
 *  - view reports such as available courseName report, list of students registered for a specific course report, students' fees report
 *  - add/remove/edit courseName from the course catalog
 * Jeremiah Roland
 * 10/24/16
 */
public class DepartmentStaffFrame
{
    /**
     * Create a constructor to make the department staff frame.  This is done so when the login frame receives the correct username and password, this frame will run.
     * Constructs a new frame that is initially invisible.
     * Throws a HeadlessException
     */
    public DepartmentStaffFrame() throws HeadlessException 
    {
    }
    /**
     * A run() method to run the department staff frame
     * Is called by the login frame when appropriate username and password are given
     */
    public void run()
    {
        JFrame departmentStaff = new JFrame("Art Department Staff");
        JButton logout = new JButton("Logout");
        //set the text font and size of the button to one that's easy to read
        logout.setFont(new Font("Arial", Font.PLAIN, 25));
        
        /**
         * When the logout button is clicked, have the program closed.  
         * Do this by adding an action listener and use an anonymous class to implement the ActionListener interface.  
         * Have the method actionPerformed() called and set what needs to be done in the method.  For this, 
         * use the dispatchEvent method to close the program when the action listener is called.
         * @param the explicit parameter of this type of call is the button it is asociated with (the logout button)
         */
        logout.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                LoginFrame myLogin = new LoginFrame();
                myLogin.run();
                departmentStaff.dispose();
            }
        });
        /** Create multiple arraylists: All of them of type string for the sake of reading/writing to/from files
         * 1: name of the course
         * 2: description of the course
         * 3: number of students enrolled in the course
         * 4: number of classes available
         * 5: pre requisits for the course
         * When adding lines to the file, organize them so every 5 lines pertains to a single course, so it is easier to organize them later in the arraylists.
         * Example, the first course "Art History" is organized with its corresponding description, size, etc.  Also, each of them correspond with the same
         * arraylist position value (all info regarding Art History is in position 0 in their arraylist)
        */
        
        ArrayList<String> courseName = new ArrayList<String>();
        ArrayList<String> courseDescription = new ArrayList<String>(); 
        ArrayList<String> courseSize = new ArrayList<String>();
        ArrayList<String> classesAvailable = new ArrayList<String>();
        ArrayList<String> preReqs = new ArrayList<String>();
        
        /**
         * Try and catch block, necessary when reading/writing I/O to and from a file
         */
        try
        {
            //Create a filewriter object to create a file to write text to a file
            FileWriter totalCourses = new FileWriter("CoursesOffered.txt");
            //create a printwriter object to actually write text to the file
            PrintWriter coursesPrinter = new PrintWriter(totalCourses);
            
            /** Course Name */ coursesPrinter.println("Art History ");
            /** Course Description */ coursesPrinter.println("Teaches the history of art in different cultures, because history alone wasn't boring enough. ");
            /** Course size */ coursesPrinter.println("HA! As if anyone would actually take this class. ");
            /** Classes Available */ coursesPrinter.println("0");
            /** Pre Reqs */ coursesPrinter.println("None");
            
            /** Course Name */ coursesPrinter.println("Why Art is Dumb ");
            /** Course Description */ coursesPrinter.println("Opens the eyes of the ignorant masses to why art is dumb. Mandatory class for all students, regardless of major. ");
            /** Course size */ coursesPrinter.println("500");
            /** Classes Available */ coursesPrinter.println("27");
            /** Pre Reqs */ coursesPrinter.println("None");
            
            /** Course Name */ coursesPrinter.println("Art Practice ");
            /** Course Description */ coursesPrinter.println("Teaches how to create actual works of art.");
            /** Course size */ coursesPrinter.println("27");
            /** Classes Available */ coursesPrinter.println("2");
            /** Pre Reqs */ coursesPrinter.println("Why Art is Dumb");
            
            coursesPrinter.close();
            
            /**
            * Print text to the file using different println statements
            * to separate text as different lines in the file.
            * Finish with printer.close() to close the file so file will be
            * readable
            */
            
            try
            {   
                /**
                 * Call the filereader class and create an object to read from the file
                 * Create an object of bufferedReader type that actually reads the text from the file
                 * Create a variable for holding each line of text read from the file
                 */
                
                FileReader reader1 = new FileReader("CoursesOffered.txt");
                BufferedReader bufReader1 = new BufferedReader(reader1);
                String line1;
                /**
                 * Now, read each of the lines in the file created above into the appropriate arraylist
                 * Set a counter variable that counts from 1 to 5.  This will represent what line we are at in the file
                 * Set if statements to see what value the counter is at.  Based on the counter, the bufferedreader will write to the appropriate arraylist
                 * The info regarding each class is grouped into 5 lines, so the first 5 lines go to one class, the next 5 lines go to the second, etc.
                 * For example, when the counter = 1, the line currently being read will be put into the class name array, when counter = 2, the line currently
                 * being read will be put into the class description array, etc., until the counter resets for the next few lines.
                 */
                int counter = 1;
                while((line1 = bufReader1.readLine()) != null)
                {
                    if(counter == 1)
                    {
                        courseName.add(line1);
                        counter ++; //sets counter to 2
                    }
                    else if (counter == 2)
                    {
                        courseDescription.add(line1);
                        counter ++; //sets counter to 3
                    }
                    else if (counter == 3)
                    {
                        courseSize.add(line1);
                        counter ++; //sets counter to 4
                    }
                    else if (counter == 4)
                    {
                        classesAvailable.add(line1);
                        counter ++; //sets counter to 5
                    }
                    else
                    {
                        preReqs.add(line1);
                        counter = 1; //sets counter to 1
                    }
                }
                //close the bufferedReader object so the file will be readable.
                bufReader1.close();
            }
            /**
             * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
             * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
             * a problem with the disk drive itself
             */
            catch(IOException e)
            {       
                System.out.println("I/O Error");
            }
        }
        /**
         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
         * a problem with the disk drive itself
         */
        catch(IOException e)
        {
            System.out.println("I/O Error");
        }
        
        
        /**
         * Create a new button for viewing reports for courses based on the current department, which is the art department.
         * Create a JPanel to hold the buttons created by the pressing of the courseReports button
         */
        JButton courseReports = new JButton("View Course Reports");
        //set the text font and size of the button to one that's easy to read
        courseReports.setFont(new Font("Arial", Font.PLAIN, 25));
        
        JPanel buttonPanel = new JPanel();
        
        //call the ActionListener interface with an abstract class
        courseReports.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                /**
                 * View/print available courses
                 * 
                 * Create two buttons to vew and print course reports
                 */
                JButton availableCourses = new JButton("Available Courses");
                JButton printCourses = new JButton("Print Available Courses");
                //set the text font and size of the button to one that's easy to read
                availableCourses.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printCourses.setFont(new Font("Arial", Font.PLAIN, 25));
                
                //call the ActionListener interface with an abstract class
                availableCourses.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over each arraylist to output the courses and their corresponding info
                         * Use a JOptionPane information message to show the output value made from the for loop
                         *          showMessageDialog(frame, what to output, "Title", type of frame)
                         */
                        String output = "";
                        for(int i = 0; i < courseName.size(); i++)
                        {
                            output += "Course Name: " + courseName.get(i).toString() + "\n";
                            output += "Course Description: " + courseDescription.get(i).toString() + "\n";
                            output += "Number of Students Taking Course: " + courseSize.get(i).toString() + "\n";
                            output += "Available Classes: " + classesAvailable.get(i).toString() + "\n";
                            output += "Pre-requisits: " + preReqs.get(i).toString() + "\n";
                            
                            output += "\n";
                        }
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "Available Courses", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                printCourses.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over each arraylist to output the courses and their corresponding info
                         * Print the output to another page
                         * Use aJOptionPane information message to tell user the output was printed to another page
                         *          showMessageDialog(frame, what to output, "Title", type of frame)
                         */
                        String output = "";
                        for(int i = 0; i < courseName.size(); i++)
                        {
                            output += "Course Name: " + courseName.get(i).toString() + "\n";
                            output += "Course Description: " + courseDescription.get(i).toString() + "\n";
                            output += "Number of Students Taking Course: " + courseSize.get(i).toString() + "\n";
                            output += "Available Classes: " + classesAvailable.get(i).toString() + "\n";
                            output += "Pre-requisits: " + preReqs.get(i).toString() + "\n";
                            
                            output += "\n";
                        }
                        System.out.println(output);
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("List of courses was printed to a different page." );
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                /**
                 * Add/remove courses
                 * 
                 * Create two buttons to add and remove courses, title appropriately 
                 */
                JButton addCourse = new JButton("Add a Course");
                JButton removeCourse = new JButton("Remove a Course");
                //set the text font and size of the button to one that's easy to read
                addCourse.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                removeCourse.setFont(new Font("Arial", Font.PLAIN, 25));
                
                //call the ActionListener interface with an abstract class
                addCourse.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {                        
                        /**
                         * Use several JOptionPane input dialog to take input from user.  Store the input in a string and add the input to the appropriate arraylist
                                 * First string: gets name of course to add and adds it to courseName arraylist
                                 * Second string: gets description of course and adds it to courseDescription arraylist
                                 * Third string: gets nubmer of students enrolled in course and adds it to courseSize arraylist
                                 * Fourth string: gets number of available classes and adds it to arraylist classesAvailable 
                                 * Fifth string: gets any pre req courses and adds them to arraylist reReqs
                         * Known issue: since the pane that takes input has a "cancel" option, if the cancel button is pressed, each pane to take info on the course to be adde still pops
                         * up, even if all panes are "cancelled", there is an error in the removeCourse button use below.  Not sure how to fix it, so if you add a course, be sure to add
                         * it and not cancel it.
                         */
                        
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("Please enter an Art Course to add: ");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        String courseToAdd = JOptionPane.showInputDialog(outputText);
                        courseName.add(courseToAdd);
                        
                        outputText.setText("Please enter a brief description for the course: ");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        String descToAdd = JOptionPane.showInputDialog(outputText);
                        courseDescription.add(descToAdd);
                        
                        outputText.setText("Please enter the amount of students taking this course ");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        String sizeAdd = JOptionPane.showInputDialog(outputText);
                        courseSize.add(sizeAdd);
                        
                        outputText.setText("Please enter amount of classes available: ");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        String availableAdd = JOptionPane.showInputDialog(outputText);
                        classesAvailable.add(availableAdd);
                        
                        outputText.setText("If there is a pre-requisit class to take this class, please enter it, or type 'none' if no pre-req: ");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        String preReqAdd = JOptionPane.showInputDialog(outputText);
                        preReqs.add(preReqAdd);
                        try
                        {
                            /**
                             * Here, we read in each element from the ArrayList, which has been updated with the add class, and write each element into the file
                             * Since a previous file of the same name exists, this new one will replace it, effectively updating the file.
                             * Use a for loop to iterate over the courseName arraylist.  Since all arraylists holding information about a specific course are the
                             * same size in length, there should be no issue with out of bounds errors.
                             * In the for loop, update the file by reading the element in each array and adding it to the file.
                             * Be sure to add the Name, Description, Size, classesAvailable, and preReqs in that order, so the above methods for viewing and printing
                             * the list of courses can work properly.  Doing it this way makes it so a courses name, description, etc., are added in the same group 
                             * Be sure to close the printwriter object outside of the for loop.
                             */
                            //Create a filewriter object to create a file to write text to a file
                            FileWriter alterSchedule = new FileWriter("CoursesOffered.txt");
                            //create a printwriter object to actually write text to the file
                            PrintWriter alterSchedPrinter = new PrintWriter(alterSchedule);
                            for(int i = 0; i < courseName.size(); i++)
                            {
                                alterSchedPrinter.println(courseName.get(i).toString());
                                alterSchedPrinter.println(courseDescription.get(i).toString());
                                alterSchedPrinter.println(courseSize.get(i).toString());
                                alterSchedPrinter.println(classesAvailable.get(i).toString());
                                alterSchedPrinter.println(preReqs.get(i).toString());
                            }                          
                            alterSchedPrinter.close();
                        }
                        /**
                         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                         * a problem with the disk drive itself
                         */
                        catch(IOException e)
                        {
                            System.out.println("I/O Error");
                        }
                    }
                });
                
                //call the ActionListener interface with an abstract class
                removeCourse.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {               
                        //if statement that sets a minimum number of courses for a department. Minimum is 3.
                        if(courseName.size() == 3)
                        {
                            /**
                             * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                             * set editable, opaque, text, and font to make it easy to read
                             * @method setEditable makes it so the user can't edit it
                             * @method setOpague(false) sets the background of the text area to clear
                             * @method setText adds text output to the text area
                             * @method setFont sets the font of the text area
                             */
                            JTextArea outputText = new JTextArea();
                            outputText.setEditable(false);
                            outputText.setOpaque(false);
                            outputText.setText("We can't have less than 3 courses in our department, otherwise we'd shut down. ");
                            outputText.setFont(outputText.getFont().deriveFont(20f));
                            
                            JOptionPane.showMessageDialog(null, outputText, "Alert!", JOptionPane.ERROR_MESSAGE);
                        }
                        else
                        {
                            /**
                             * Use a for loop to iterate over the arraylist of courses in the department, and add each to the output value, along with a corresponding number
                             * The number matches up with the course's position in the arraylist
                             * Use a JOptionPane input dialog to take input and parse it to an integer.  This takes a number value from the user and removes the course 
                             * corresponding to the number, along with the course's details in the other arraylists.
                             */
                            String output = "";
                            for(int i = 0; i < courseName.size(); i++)
                            {
                                String list = courseName.get(i).toString();
                                output += list + " [" + i + "]" + "\n";       
                            }                            
                            /**
                             * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                             * set editable, opaque, text, and font to make it easy to read
                             * @method setEditable makes it so the user can't edit it
                             * @method setOpague(false) sets the background of the text area to clear
                             * @method setText adds text output to the text area
                             * @method setFont sets the font of the text area
                             */
                            JTextArea outputText = new JTextArea();
                            outputText.setEditable(false);
                            outputText.setOpaque(false);
                            outputText.setText(output + "The list above shows current courses. " + 
                                                "Please enter the number corresponding to a course to remove. Changes will automatically be saved. ");
                            outputText.setFont(outputText.getFont().deriveFont(20f));
                            
                            int answer = Integer.parseInt(JOptionPane.showInputDialog(outputText));
                            courseName.remove(answer);
                            courseDescription.remove(answer);
                            courseSize.remove(answer);
                            classesAvailable.remove(answer);
                            preReqs.remove(answer);
                            try
                            {
                                /**
                                 * Here, we read in each element from the ArrayList, which has been updated with the add class, and write each element into the file
                                 * Since a previous file of the same name exists, this new one will replace it, effectively updating the file.
                                 * Use a for loop to iterate over the courseName arraylist.  Since all arraylists holding information about a specific course are the
                                 * same size in length, there should be no issue with out of bounds errors.
                                 * In the for loop, update the file by reading the element in each array and adding it to the file.
                                 * Be sure to add the Name, Description, Size, classesAvailable, and preReqs in that order, so the above methods for viewing and printing
                                 * the list of courses can work properly.  Doing it this way makes it so a courses name, description, etc., are added in the same group 
                                 * Be sure to close the printwriter object outside of the for loop.
                                 */
                                //int counter = 1; 
                                //Create a filewriter object to create a file to write text to a file
                                FileWriter alterSchedule = new FileWriter("CoursesOffered.txt");
                                //create a printwriter object to actually write text to the file
                                PrintWriter alterSchedPrinter = new PrintWriter(alterSchedule);
                                for(int i = 0; i < courseName.size(); i++)
                                {
                                    alterSchedPrinter.println(courseName.get(i).toString());
                                    alterSchedPrinter.println(courseDescription.get(i).toString());
                                    alterSchedPrinter.println(courseSize.get(i).toString());
                                    alterSchedPrinter.println(classesAvailable.get(i).toString());
                                    alterSchedPrinter.println(preReqs.get(i).toString());
                                }                          
                                alterSchedPrinter.close();
                            }
                            /**
                             * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                             * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                             * a problem with the disk drive itself
                             */
                            catch(IOException e)
                            {
                                System.out.println("I/O Error");
                            }
                        }
                    }
                });
                
                /**
                 * View/print list of students
                 * 
                 * Create two buttons, for viewing and printing a list of students in a course
                 * Create an arraylist of students to represent any student (the obligatory student #x) along with the student's average, attendance, etc.
                 */
                JButton listOfStudents = new JButton("List of Students in Course");
                JButton printStudentList = new JButton("Print list of Students");
                //set the text font and size of the button to one that's easy to read
                listOfStudents.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printStudentList.setFont(new Font("Arial", Font.PLAIN, 25));
                
                ArrayList<String> students = new ArrayList<String>();                
                            
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                try
                {
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter sList = new FileWriter("ListOfStudents.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter sListPrinter = new PrintWriter(sList);
                    
                    sListPrinter.println("     Obligatory Student #X" + "\n" + "          Attendance:....." + "\n" + "          Test/Quiz Avg:......" + "\n" 
                            + "          Homework Avg:......" + "\n" + "          Overall Avg:......");
                    sListPrinter.close();
                    
                    /**
                    * Print text to the file using different println statements
                    * to separate text as different lines in the file.
                    * Finish with printer.close() to close the file so file will be
                    * readable
                    */
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         * Put each read line from the file into the array list
                         */
                        
                        FileReader reader2 = new FileReader("ListOfStudents.txt");
                        BufferedReader bufReader2 = new BufferedReader(reader2);
                        String line2;
                        
                        while((line2 = bufReader2.readLine()) != null)
                        {
                            students.add(line2);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader2.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                            
                //call the ActionListener interface with an abstract class
                listOfStudents.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {                        
                        /**
                         * Use a for loop to iterate over the course list and student list to print the course name and number of students in the course.
                         * Assign the values to the output variable
                         * Use JOptionPane message dialog to show the output
                         */
                        String output = "";
                        for(int i = 0; i < courseName.size(); i++)
                        {
                            output += courseName.get(i).toString() + "\n";
                            output += students.get(0).toString() + "\n";
                        }
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "List of Students for Specific Courses", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                printStudentList.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over the course list and student list to print the course name and number of students in the course.
                         * Assign the values to the output variable
                         * Print the output to another page
                         * Use JOptionPane message dialog to tell user the output was printed to another page
                         */
                        String output = "";
                        for(int i = 0; i < courseName.size(); i++)
                        {
                            output += courseName.get(i).toString() + "\n";
                            output += students.get(0).toString() + "\n";
                        }
                        System.out.println(output);
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("List of students per course has been printed to another page.");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                /**
                 * View/print students' fees
                 * 
                 * Create two buttons, to view and print a student's info on their fees
                 * Create an arraylist to hold the student's name and whether or not their fees are paid
                 */
                
                JButton studentFees = new JButton("Students' Fees");
                JButton printFees = new JButton("Print Students' Fees");
                //set the text font and size of the button to one that's easy to read
                studentFees.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printFees.setFont(new Font("Arial", Font.PLAIN, 25));
                
                ArrayList<String> feesPaid = new ArrayList<String>();
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                try
                {
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter fList = new FileWriter("Student'sFeesList.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter fListPrinter = new PrintWriter(fList);
                    
                    fListPrinter.println("Obligatory Student #1" + "\n" + "Fees Paid?: Yes");
                    fListPrinter.println("Obligatory Student #2" + "\n" + "Fees Paid?: No");
                    fListPrinter.println("Obligatory Student #3" + "\n" + "Fees Paid?: No");
                    fListPrinter.println("Obligatory Student #4" + "\n" + "Fees Paid?: Yes");
                    fListPrinter.close();
                    
                    /**
                    * Print text to the file using different println statements
                    * to separate text as different lines in the file.
                    * Finish with printer.close() to close the file so file will be
                    * readable
                    */
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         * Put each read line from the file into the array list
                         */
                        
                        FileReader reader3 = new FileReader("Student'sFeesList.txt");
                        BufferedReader bufReader3 = new BufferedReader(reader3);
                        String line3;
                        
                        while((line3 = bufReader3.readLine()) != null)
                        {
                            feesPaid.add(line3);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader3.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                
                //call the ActionListener interface with an abstract class
                studentFees.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over the feesPaid arraylist to output the values
                         * Set the values to a string output
                         * Use JOptionPane message dialog to show the output
                         */
                        String output = "";
                        for(int i = 0; i < feesPaid.size(); i++)
                        {
                            output += feesPaid.get(i) + "\n";
                            output += "\n";
                        }
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "List of Student's Fees", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                          
                //call the ActionListener interface with an abstract class
                printFees.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over the feesPaid arraylist to output the values
                         * Set the values to a string output
                         * Print the output to another page
                         * Use JOptionPane message dialog to tell user the output was printed to another page
                         */
                        String output = "";
                        for(int i = 0; i < feesPaid.size(); i++)
                        {
                            output += feesPaid.get(i) + "\n";
                            output += "\n";
                        }
                        System.out.println(output);
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("List of courses has been printed to another page." );
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(departmentStaff, outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                /**
                 * Close buttonPanel
                 * 
                 * Create a button to close the JPanel created to hold all of the buttons created above
                 */
                
                JButton close = new JButton("Close");
                //set the text font and size of the button to one that's easy to read
                close.setFont(new Font("Arial", Font.PLAIN, 25));
                
                //call the ActionListener interface with an abstract class
                close.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        //remove all the buttons previously added
                        buttonPanel.remove(availableCourses);
                        buttonPanel.remove(printCourses);
                        buttonPanel.remove(listOfStudents);
                        buttonPanel.remove(printStudentList);
                        buttonPanel.remove(studentFees);
                        buttonPanel.remove(printFees);
                        buttonPanel.remove(addCourse);
                        buttonPanel.remove(removeCourse);
                        buttonPanel.remove(close);
                        
                        //remove and repaint the JPanel and repaint the frame to get rid of leftover white space
                        departmentStaff.remove(buttonPanel);
                        buttonPanel.revalidate();
                        buttonPanel.repaint();
                        departmentStaff.revalidate();
                        departmentStaff.repaint();
                    }
                });
                
                //add all buttons created from courseReports being pressed to the JPanel
                buttonPanel.add(availableCourses);
                buttonPanel.add(listOfStudents);
                buttonPanel.add(studentFees);
                buttonPanel.add(addCourse);
                buttonPanel.add(close);
                buttonPanel.add(printCourses);
                buttonPanel.add(printStudentList);
                buttonPanel.add(printFees);
                buttonPanel.add(removeCourse);
                
                //set the layout, size, and visibility of the JPanel and add it to the frame
                buttonPanel.setLayout(new GridLayout(2, 3));
                departmentStaff.pack();
                buttonPanel.setVisible(true);
                departmentStaff.add(buttonPanel);
            }
        });
        
        /**
         * @method setDefaultCloseOperation(), used to close the program if the window of the program is closed, so as to avoid the program continuing to run after user closes the window
         * add all buttons neccessary 
         * use the pack() to set the size of the frame to fit all of its contents
         * then, set the frame to visible
         */
        departmentStaff.setLayout(new GridLayout(10, 1));
        
        departmentStaff.add(courseReports);
        departmentStaff.add(logout);
        
        departmentStaff.pack();
        departmentStaff.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        departmentStaff.setVisible(true);
    }
}

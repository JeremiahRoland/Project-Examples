import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.*; 
/**
 * An Instructor frame, allowing the instructor to view his/her teaching classes, view/print class enrollments
 * Jeremiah Roland
 * 10/24/16
 */
public class InstructorFrame
{
    /**
     * Create a constructor to make the instructor frame.  This is done so when the login frame receives the correct username and password, this frame will run.
     * Constructs a new frame that is initially invisible.
     * Throws a HeadlessException
     */
    public InstructorFrame() throws HeadlessException 
    {
    }
    /**
     * A run() method to run the instructor frame
     * Is called by the login frame when appropriate username and password are given
     */
    public void run()
    {
        JFrame instructorFrame = new JFrame("Instructor");
        JButton logout = new JButton("Logout");
        //set the text font and size of the button to one that's easy to read
        logout.setFont(new Font("Arial", Font.PLAIN, 25));
        
        /**
         * When the logout button is clicked, have the program closed.  
         * Do this by adding an action listener and use an anonymous class to implement the ActionListener interface.  
         * Have the method actionPerformed() called and set what needs to be done in the method.  For this, 
         * use the dispatchEvent method to close the program when the action listener is called.
         * @param the explicit parameter of this type of call is the button it is asociated with (the logout button)
         */
        logout.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                LoginFrame myLogin = new LoginFrame();
                myLogin.run();
                instructorFrame.dispose();
            }
        });
        
        /**
         * Create a button to represent the instructor's students
         * Create a JPanel to hold all information created within the instructor's students button
         */
        JButton myStudents = new JButton("My Students");
        //set the text font and size of the button to one that's easy to read
        myStudents.setFont(new Font("Arial", Font.PLAIN, 25));
        
        JPanel myPanel = new JPanel();
        
        //call actionlistener interface with an abstract class
        myStudents.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                JButton myClasses = new JButton("My Classes");
                //set the text font and size of the button to one that's easy to read
                myClasses.setFont(new Font("Arial", Font.PLAIN, 25));
                //Create an arraylist of type String for holding lines to be traversed over the file.
                ArrayList<String> myClassList = new ArrayList<String>();
                
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                try
                {
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter classList = new FileWriter("myClasses.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter classPrinter = new PrintWriter(classList);
                    
                    /**
                     * Print text to the file using different println statements
                     * to separate text as different lines in the file.
                     * Finish with printer.close() to close the file so file will be
                     * readable
                     */
                    classPrinter.println("ENGL 1020");
                    classPrinter.println("ENGL 2000");
                    classPrinter.close();
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */
                        
                        FileReader reader1 = new FileReader("myClasses.txt");
                        BufferedReader bufReader1 = new BufferedReader(reader1);
                        String line1;
                        /**
                         * A while loop for reading each line of text in the file 
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isnt empty (or null).
                         */
                        while((line1 = bufReader1.readLine()) != null)
                        {
                            myClassList.add(line1);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader1.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                //call actionlistener interface with an abstract class
                myClasses.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Create an empty string to hold values from arrayList
                         * Use a for loop to iterate over the arraylist to add values to the string
                         * Use JOptionPane to show the values on screen
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                         
                        String output = "";
                        for(int i = 0; i < myClassList.size(); i++)
                        {
                            output += myClassList.get(i).toString();
                            output += "\n";
                        }
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "Your Classes", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                /**
                 * View/Print class enrollments
                 * 
                 * Create an arraylist to represent the roll for a class
                 * create two buttons to view and to print the roll
                 */
                ArrayList<String> roll = new ArrayList<String>();
                
                JButton classRoll = new JButton("Class Roll");
                JButton printRoll = new JButton("Print Roll");
                //set the text font and size of the button to one that's easy to read
                classRoll.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printRoll.setFont(new Font("Arial", Font.PLAIN, 25));
                
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                try
                {
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter rollReader = new FileWriter("classRoll.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter rollPrinter = new PrintWriter(rollReader);
                    
                    /**
                     * Print text to the file using different println statements
                     * to separate text as different lines in the file.
                     * Finish with printer.close() to close the file so file will be
                     * readable
                     */
                    rollPrinter.println("Obligatory Student X");
                    rollPrinter.println("Obligatory Student X");
                    rollPrinter.close();
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */
                        
                        FileReader reader2 = new FileReader("classRoll.txt");
                        BufferedReader bufReader2 = new BufferedReader(reader2);
                        String line2;
                        /**
                         * A while loop for reading each line of text in the file 
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isnt empty (or null).
                         */
                        while((line2 = bufReader2.readLine()) != null)
                        {
                            roll.add(line2);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader2.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                //call actionlistener interface with an abstract class
                classRoll.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Create an empty string to hold values from arrayList
                         * Use a for loop to iterate over the arraylist to add values to the string
                         * Use JOptionPane to show the values on screen
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                         
                        String output = "";
                        for(int i = 0; i < roll.size(); i++)
                        {
                            output += roll.get(i).toString();
                            output += "\n";
                        }
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("Your roll for class " + myClassList.get(0).toString() + " is: " + "\n" + output
                                            + "\n" + "Your roll for class " + myClassList.get(1).toString() + " is: " + "\n" + output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "Your Classes", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                //call actionlistener interfrace with an abstract class
                printRoll.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        try
                        {   
                            /**
                             * Call the filereader class and create an object to read from the file
                             * Create an object of bufferedReader type that actually reads the text from the file
                             * Create a variable for holding each line of text read from the file
                             * 
                             * Use this to print the file directly to another screen
                             */
                            
                            FileReader readerPrint = new FileReader("classRoll.txt");
                            BufferedReader bufPrint = new BufferedReader(readerPrint);
                            String linePrint;
                            int i = 0;
                            /**
                             * A while loop for reading each line of text in the file 
                             * Condition for while loop sets the null string to what the bufferedReader object
                             * read in the previous line from the file. Continues to print file until linePrint is null
                             */
                            while((linePrint = bufPrint.readLine()) != null)
                            {
                                System.out.println("Your roll for class " + myClassList.get(i).toString() + " is: " + "\n" + linePrint);
                                System.out.println("");
                                i++;
                            }
                            //close the bufferedReader object so the file will be readable.
                            bufPrint.close();
                        }
                        /**
                         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                         * a problem with the disk drive itself
                         */
                        catch(IOException e)
                        {       
                            System.out.println("I/O Error");
                        }
                        
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("Roll was printed to a different tab.");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame,  outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                /**
                 * Create a close button to close the JPanel containing the buttons created
                 */
                JButton close = new JButton("Close");
                //set the text font and size of the button to one that's easy to read
                close.setFont(new Font("Arial", Font.PLAIN, 25));
                
                //call actionlistener interface with abstract class
                close.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        //remove buttons
                        myPanel.remove(myClasses);
                        myPanel.remove(classRoll);
                        myPanel.remove(printRoll);
                        myPanel.remove(close);
                        
                        //remove JPanel and revalidate & repaint the JPanel and frame, to eliminate extra white space
                        instructorFrame.remove(myPanel);
                        myPanel.revalidate();
                        myPanel.repaint();
                        instructorFrame.revalidate();
                        instructorFrame.repaint();
                    }
                });
                
                //add buttons to the panel and set size, layout, and visibility.  Then add JPanel to frame
                myPanel.add(myClasses);
                myPanel.add(classRoll);
                myPanel.add(printRoll);
                myPanel.add(close);
                
                myPanel.setLayout(new GridLayout(2, 5));
                myPanel.setVisible(true);
                instructorFrame.pack();
                instructorFrame.add(myPanel);
            }
        });
        
        JButton otherStudents = new JButton("Other Student Reports");
        //set the text font and size of the button to one that's easy to read
        otherStudents.setFont(new Font("Arial", Font.PLAIN, 25));
        
        JPanel otherPanel = new JPanel();
        otherStudents.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                /**
                 * View/print students' fees
                 * 
                 * Create two buttons, to view and print a student's info on their fees
                 * Create an arraylist to hold the student's name and whether or not their fees are paid
                 */
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                ArrayList<String> feesPaid = new ArrayList<String>();
                
                try
                {
                    /**
                     * Teaching classes
                     * 
                     * Create button to show classes the instructor is teaching
                     * Create an arraylist to hold the classes
                     */
                    /**
                     * Read/write to file
                     */
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter feesWriter = new FileWriter("feesList.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter feesPrinter = new PrintWriter(feesWriter);
                    
                    /**
                     * Print text to the file using different println statements
                     * to separate text as different lines in the file.
                     * Finish with printer.close() to close the file so file will be
                     * readable
                     */
                    feesPrinter.println("Obligatory Student #1" + "\n" + "Fees Paid?: Yes");
                    feesPrinter.println("Obligatory Student #2" + "\n" + "Fees Paid?: No");
                    feesPrinter.println("Obligatory Student #3" + "\n" + "Fees Paid?: No");
                    feesPrinter.println("Obligatory Student #4" + "\n" + "Fees Paid?: Yes");
                    feesPrinter.close();
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */
                        
                        FileReader reader3 = new FileReader("feesList.txt");
                        BufferedReader bufReader3 = new BufferedReader(reader3);
                        String line3;
                        /**
                         * A while loop for reading each line of text in the file
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isnt empty (or null).
                         */
                        while((line3 = bufReader3.readLine()) != null)
                        {
                            feesPaid.add(line3);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader3.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                
                JButton studentFees = new JButton("Students' Fees");
                JButton printFees = new JButton("Print Students' Fees");
                //set the text font and size of the button to one that's easy to read
                studentFees.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printFees.setFont(new Font("Arial", Font.PLAIN, 25));
                
                
                //call actionlistener interface with abstract class
                studentFees.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        /**
                         * Use a for loop to iterate over the feesPaid arraylist to output the values
                         * Set the values to a string output
                         * Use JOptionPane message dialog to show the output
                         */
                        String output = "";
                        for(int i = 0; i < feesPaid.size(); i++)
                        {
                            output += feesPaid.get(i) + "\n";
                            output += "\n";
                        }
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(output);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "List of Student's Fees", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                                
                printFees.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        try
                        {   
                            /**
                             * Call the filereader class and create an object to read from the file
                             * Create an object of bufferedReader type that actually reads the text from the file
                             * Create a variable for holding each line of text read from the file
                             * 
                             * Use this to print the file directly to another screen
                             */
                            
                            FileReader readerPrint = new FileReader("feesList.txt");
                            BufferedReader bufPrint = new BufferedReader(readerPrint);
                            String linePrint;
                            /**
                             * A while loop for reading each line of text in the file 
                             * Condition for while loop sets the null string to what the bufferedReader object
                             * read in the previous line from the file. Continues to print file until linePrint is null
                             */
                            while((linePrint = bufPrint.readLine()) != null)
                            {
                                System.out.println(linePrint);
                                System.out.println("");
                            }
                            //close the bufferedReader object so the file will be readable.
                            bufPrint.close();
                        }
                        /**
                         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                         * a problem with the disk drive itself
                         */
                        catch(IOException e)
                        {       
                            System.out.println("I/O Error");
                        }
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("List of student's fees has been printed to another page." );
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                /**
                 * View/print list of students
                 * 
                 * Create two buttons, for viewing and printing a list of students in a course
                 * Create an arraylist of students to represent any student (the obligatory student #x) along with the student's average, attendance, etc.
                 * Create an arraylist to hold other courses
                 */
                JButton listOfStudents = new JButton("List of Students in Course");
                JButton printStudentList = new JButton("Print list of Students");
                //set the text font and size of the button to one that's easy to read
                listOfStudents.setFont(new Font("Arial", Font.PLAIN, 25));
                //set the text font and size of the button to one that's easy to read
                printStudentList.setFont(new Font("Arial", Font.PLAIN, 25));
                
                ArrayList<String> students = new ArrayList<String>();
                ArrayList<String> courseStudents = new ArrayList<String>();
                
                /**
                 * Try and catch block, necessary when reading/writing I/O to and from a file
                 */
                try
                {
                    /**
                     * Print text to the file using different println statements
                     * to separate text as different lines in the file.
                     * Finish with printer.close() to close the file so file will be
                     * readable
                     */
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter studentReader = new FileWriter("otherStudents.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter studentPrinter = new PrintWriter(studentReader);
                    
                    studentPrinter.println("Obligatory Student #X" + "\n" + "          Attendance:....." + "\n" + "          Test/Quiz Avg:......" + "\n" 
                            + "          Homework Avg:......" + "\n" + "          Overall Avg:......");
                    studentPrinter.close();
                    
                    try
                    {   
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */
                        
                        FileReader reader4 = new FileReader("otherStudents.txt");
                        BufferedReader bufReader4 = new BufferedReader(reader4);
                        String line4;
                        /**
                         * A while loop for reading each line of text in the file myClasses.txt
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isnt empty (or null).
                         */
                        while((line4 = bufReader4.readLine()) != null)
                        {
                            students.add(line4);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader4.close();
                    }
                    /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException e)
                    {       
                        System.out.println("I/O Error");
                    }
                }
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                try
                {
                    /**
                     * Print text to the file using different println statements
                     * to separate text as different lines in the file.
                     * Finish with printer.close() to close the file so file will be
                     * readable
                     */
                    //Create a filewriter object to create a file to write text to a file
                    FileWriter courseReader = new FileWriter("course'sStudents.txt");
                    //create a printwriter object to actually write text to the file
                    PrintWriter coursePrinter = new PrintWriter(courseReader);
                    
                    coursePrinter.println("Statistics: ");
                    coursePrinter.println("Calculus: ");
                    coursePrinter.println("Algebra: ");  
                    coursePrinter.println("Art History: ");
                    coursePrinter.println("Why Art is Dumb: ");        
                    coursePrinter.println("Art Practice: ");
                    coursePrinter.close(); 
                    try
                    {
                        /**
                         * Call the filereader class and create an object to read from the file
                         * Create an object of bufferedReader type that actually reads the text from the file
                         * Create a variable for holding each line of text read from the file
                         */
                        FileReader reader5 = new FileReader("course'sStudents.txt");
                        BufferedReader bufReader5 = new BufferedReader(reader5);
                        String line5;
                        /**
                         * A while loop for reading each line of text in the file myClasses.txt
                         * Condition for while loop sets the null string to what the bufferedReader object
                         * read in the previous line from the file.  While loop continues to add lines
                         * to the arraylist so long as the line isnt empty (or null).
                         */
                        while((line5 = bufReader5.readLine()) != null)
                        {
                            courseStudents.add(line5);
                        }
                        //close the bufferedReader object so the file will be readable.
                        bufReader5.close();
                    }
                     /**
                     * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                     * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                     * a problem with the disk drive itself
                     */
                    catch(IOException a)
                    {
                        System.out.println("I/O Error");
                    }
                }
                catch(IOException e)
                {
                    System.out.println("I/O Error");
                }
                //create output strings to hold each course and its students
                String statsOutput = courseStudents.get(0).toString() + "\n" + students.get(0).toString() + "\n";
                String calcOutput = courseStudents.get(1).toString() + "\n" + students.get(0).toString() + "\n";
                String algOutput = courseStudents.get(2).toString() + "\n" + students.get(0).toString() + "\n";
                String histOutput = courseStudents.get(3).toString() + "\n" + "HHAHA, yeah, no one is taking this class." + "\n";
                String dumbOutput = courseStudents.get(4).toString() + "\n" + students.get(0).toString() + "\n";
                String practOutput = courseStudents.get(5).toString() + "\n" + students.get(0).toString() + "\n";
                
                listOfStudents.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {                        
                        //use JOptionPane message dialog to show output strings created above
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText(statsOutput + "\n" + calcOutput + "\n" + algOutput + "\n" + histOutput + "\n" + dumbOutput + "\n" + practOutput);
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "List of Students for Specific Courses", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                printStudentList.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        //Print output strings to another page
                        //Use JOptionPane message dialog to tell user output was printed to another page
                        System.out.println(statsOutput + "\n" + calcOutput + "\n" + algOutput + "\n" + histOutput + "\n" + dumbOutput + "\n" + practOutput);
                        /**
                         * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                         * set editable, opaque, text, and font to make it easy to read
                         * @method setEditable makes it so the user can't edit it
                         * @method setOpague(false) sets the background of the text area to clear
                         * @method setText adds text output to the text area
                         * @method setFont sets the font of the text area
                         */
                        JTextArea outputText = new JTextArea();
                        outputText.setEditable(false);
                        outputText.setOpaque(false);
                        outputText.setText("List of students per course has been printed to another page.");
                        outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                        JOptionPane.showMessageDialog(instructorFrame, outputText, "Attention", JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                /**
                 * Create a close button to close the JPanel 
                 */
                JButton close = new JButton("Close");
                //set the text font and size of the button to one that's easy to read
                close.setFont(new Font("Arial", Font.PLAIN, 25));
        
                //call the actionlistener interface with an abstract class
                close.addActionListener(new ActionListener()
                {
                    public void actionPerformed(ActionEvent exit)
                    {
                        //remove the buttons from the JPanel
                        otherPanel.remove(studentFees);
                        otherPanel.remove(printFees);
                        otherPanel.remove(listOfStudents);
                        otherPanel.remove(printStudentList);
                        
                        //remove the JPanel from the frame and repaint & revalidate the frame and JPanel to eliminate extra white space
                        instructorFrame.remove(otherPanel);
                        otherPanel.revalidate();
                        otherPanel.repaint();
                        instructorFrame.revalidate();
                        instructorFrame.repaint();
                    }
                });
                
                //add buttons to the JPanel
                otherPanel.add(listOfStudents);
                otherPanel.add(studentFees);
                otherPanel.add(close);
                otherPanel.add(printStudentList);
                otherPanel.add(printFees);
                
                //set layout and visibility of JPanel, then add to frame
                otherPanel.setLayout(new GridLayout(2, 5));
                otherPanel.setVisible(true);
                instructorFrame.pack();
                instructorFrame.add(otherPanel);
            }
        });
        
        /**
         * @method setDefaultCloseOperation(), used to close the program if the window of the program is closed, so as to avoid the program continuing to run after user closes the window
         * add all buttons neccessary 
         * use the pack() to set the size of the frame to fit all of its contents
         * then, set the frame to visible
         */
        instructorFrame.setLayout(new GridLayout(10, 1));
        instructorFrame.add(myStudents);
        instructorFrame.add(otherStudents);
        instructorFrame.add(logout);
        
        instructorFrame.pack();
        instructorFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        instructorFrame.setVisible(true);
    }
}

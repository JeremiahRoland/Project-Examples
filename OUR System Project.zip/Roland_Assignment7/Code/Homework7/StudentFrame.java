import java.awt.*;
import java.awt.event.*;
import javax.swing.*; 
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.*;  
/**
 * Allows student to view schedule, add/remove classes, check available courses by different departments, print schedule for semester
 * Jeremiah Roland
 * 10/24/16
 */
public class StudentFrame 
{
    /**
     * Create a constructor to make the student frame.  This is done so when the login frame receives the correct username and password, this frame will run.
     * Constructs a new frame that is initially invisible.
     * Throws a HeadlessException
     */
    public StudentFrame() throws HeadlessException 
    {
    }
    /**
     * A run() method to run the student frame
     * Is called by the login frame when appropriate username and password are given
     */
    public void run()
    {
        //create the frame
        JFrame studentFrame = new JFrame("Student");
        
        //create a button logout, to log out of the frame
        JButton logout = new JButton("Logout");
        //set the text font and size of the button to one that's easy to read
        logout.setFont(new Font("Arial", Font.PLAIN, 25));
        /**
         * When the logout button is clicked, have the program closed.  
         * Do this by adding an action listener and use an anonymous class to implement the ActionListener interface.  
         * Have the method actionPerformed(ActionEvent name) called and set what needs to be done in the method.  For this,call the LoginFrame constructor, 
         * then the run method to show the login frame. Then dispose of this frame
         * @param the implicit parameter of this type of call is the button it is asociated with (the logout button)
         */
        logout.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                LoginFrame myLogin = new LoginFrame();
                myLogin.run();
                studentFrame.dispose();
            }
        });
        /**
         * Schedule code
         * 
         * Create an arraylist of type string to hold the classes the student currently is enrolled in
         * Then create a JButton to show the schedule when it is clicked.  Add the button to the frame.
         * Then, add an action listener and use an anonymous class to implement the ActionListener interface.
         * Have the method actionPerformed(ActionEvent name) called.
         * When the button is pressed, a for loop prints the ArrayList created earlier to a string value and then outputs that 
         * value into a JOptionPane
         */
        ArrayList<String> schedule = new ArrayList<String>();
        
        /**
         * Try and catch block, necessary when reading/writing I/O to and from a file
         */
        try
        {
            //Create a filewriter object to create a file to write text to a file
            FileWriter schedList = new FileWriter("mySchedule.txt");
            //create a printwriter object to actually write text to the file
            PrintWriter schedPrinter = new PrintWriter(schedList);
            
            /**
             * Print text to the file using different println statements
             * to separate text as different lines in the file.
             * Finish with printer.close() to close the file so file will be
             * readable
             */
            schedPrinter.println("Statistics");
            schedPrinter.println("Psychology");
            schedPrinter.println("English 1020");
            schedPrinter.println("Computer Ethics");
            schedPrinter.close();
            
            try
            {   
                /**
                 * Call the filereader class and create an object to read from the file
                 * Create an object of bufferedReader type that actually reads the text from the file
                 * Create a variable for holding each line of text read from the file
                 */
                
                FileReader reader1 = new FileReader("mySchedule.txt");
                BufferedReader bufReader1 = new BufferedReader(reader1);
                String line1;
                /**
                 * A while loop for reading each line of text in the file myClasses.txt
                 * Condition for while loop sets the null string to what the bufferedReader object
                 * read in the previous line from the file.  While loop continues to add lines
                 * to the arraylist so long as the line isnt empty (or null).
                 */
                while((line1 = bufReader1.readLine()) != null)
                {
                    schedule.add(line1);
                }
                //close the bufferedReader object so the file will be readable.
                bufReader1.close();
            }
            /**
             * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
             * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
             * a problem with the disk drive itself
             */
            catch(IOException e)
            {       
                System.out.println("I/O Error");
            }
        }
        /**
         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
         * a problem with the disk drive itself
         */
        catch(IOException e)
        {
            System.out.println("I/O Error");
        }
        
        
        JButton mySchedule = new JButton("My Schedule");
        //set the text font and size of the button to one that's easy to read
        mySchedule.setFont(new Font("Ariel", Font.PLAIN, 25));
        studentFrame.add(mySchedule);
        
        //call the ActionListener interface with an abstract class
        mySchedule.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                String output = "";
                for(int i = 0; i < schedule.size(); i++)
                {
                    //for loop goes through each value in the arraylist and prints it to the string output
                    String list = schedule.get(i).toString();
                    output += list + "\n";       
                } 
                /**
                 * Create a JTextArea to display the output created above
                 * set editable, opaque, text, and font to make it easy to read
                 * @method setEditable makes it so the user can't edit it
                 * @method setOpague(false) sets the background of the text area to clear
                 * @method setText adds text output to the text area
                 * @method setFont sets the font of the text area
                 */
                JTextArea outputText = new JTextArea();
                outputText.setEditable(false);
                outputText.setOpaque(false);
                outputText.setText(output);
                outputText.setFont(outputText.getFont().deriveFont(20f));
                
                JOptionPane.showMessageDialog(studentFrame, outputText, "Schedule", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        /**
         * Add/Remove classes code
         * 
         * Create a boolean value to represent whether or not the student has paid his/her fees
         * Create a new button to allow student to alter schedule and add it to the frame
         * Then, add an action listener and use an anonymous class to implement the ActionListener interface.
         * Have the method actionPerformed(ActionEvent name) called.  When the button is pressed, a new JPanel is created to hold the buttons that appear
         */
        boolean feesPaid = true;
        JButton alterClasses = new JButton("Alter Schedule");
        //set the text font and size of the button to one that's easy to read
        alterClasses.setFont(new Font("Arial", Font.PLAIN, 25));
        
        studentFrame.add(alterClasses);
        alterClasses.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                /**
                 * Create a new JPanel to hold the additional buttons created when the ActionListener method is called (the button is pressed), and add the buttons to the JPanel
                 */
                JPanel buttonPanel2 = new JPanel();
                JButton addClass = new JButton("Add Class");
                //set the text font and size of the button to one that's easy to read
                addClass.setFont(new Font("Arial", Font.PLAIN, 25));
                
                 /**
                 * Create another button and add it to the buttonPanel created earlier
                 */
                JButton removeClass = new JButton("Remove Class");
                //set the text font and size of the button to one that's easy to read
                removeClass.setFont(new Font("Arial", Font.PLAIN, 25));
                
                /**
                 * create a final button to remove the JPanel created when the alterClasses button was pressed
                 * add it to the buttonPanel.
                 */
                JButton closeAddRemove = new JButton("Close");
                //set the text font and size of the button to one that's easy to read
                closeAddRemove.setFont(new Font("Arial", Font.PLAIN, 25));
                
                if(feesPaid == true)
                {                 
                    buttonPanel2.add(addClass);
                    //call the ActionListener interface with an abstract class
                    addClass.addActionListener(new ActionListener()
                    {
                        public void actionPerformed(ActionEvent exit)
                        {
                            /**
                             * if/else statement with embedded if/else statement
                             * the outer if/else is for checking if the student has paid his/her fees, which is determined by the boolean value created above
                             * the inner if/else is for adding a class to the student's schedule.  The if triggers if the student has 5 classes already.  If so, then the
                             * student cannot register for more classes, as they are only allowed to have 5 at most.
                             * Else, if the student has < 5 classes, then a class is added to the student's schedule.  
                             */
                            if(schedule.size() == 5)
                            {
                                /** use JOPtionPane Error Message to show student that they have too many classes
                                 * (null, "text to show", "title of Pane", type of pane)
                                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                                 * set editable, opaque, text, and font to make it easy to read
                                 * @method setEditable makes it so the user can't edit it
                                 * @method setOpague(false) sets the background of the text area to clear
                                 * @method setText adds text output to the text area
                                 * @method setFont sets the font of the text area
                                 */
                                JTextArea outputText = new JTextArea();
                                outputText.setEditable(false);
                                outputText.setOpaque(false);
                                outputText.setText("You currently have 5 classes, you can't have more." + "\n" 
                                                   + "If you wish to add a new class, remove one you are currently enrolled in.");
                                outputText.setFont(outputText.getFont().deriveFont(20f));
                                
                                JOptionPane.showMessageDialog(null, outputText, "Alert!", JOptionPane.ERROR_MESSAGE);
                            }
                            else
                            {
                                /** 
                                 * use JOptionPane to take input from user.  The input is taken as a string and stored in a string variable
                                 * the input is then added to the student's schedule
                                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                                 * set editable, opaque, text, and font to make it easy to read
                                 * @method setEditable makes it so the user can't edit it
                                 * @method setOpague(false) sets the background of the text area to clear
                                 * @method setText adds text output to the text area
                                 * @method setFont sets the font of the text area
                                 */
                                JTextArea outputText = new JTextArea();
                                outputText.setEditable(false);
                                outputText.setOpaque(false);
                                outputText.setText("Please enter a class to add to your schedule. ");
                                outputText.setFont(outputText.getFont().deriveFont(20f));
                                
                                String classToAdd = JOptionPane.showInputDialog(outputText);
                                schedule.add(classToAdd);
                                /**
                                 * Try and catch block, necessary when reading/writing I/O to and from a file
                                 */
                                try
                                {
                                    /**
                                     * Here, we read in each element from the ArrayList, which has been updated with the added class, and write each element into the file
                                     * mySchedule.txt.  Since a previous file of the same name exists, this new one will replace it, effectively updating the file.
                                     * Be sure to close the printwriter object outside of the for loop.
                                     */
                                    //Create a filewriter object to create a file to write text to a file
                                    FileWriter alterSchedule = new FileWriter("mySchedule.txt");
                                    //create a printwriter object to actually write text to the file
                                    PrintWriter alterSchedPrinter = new PrintWriter(alterSchedule);
                                    for(int i = 0; i < schedule.size(); i++)
                                    {
                                        //iterate over each element of the array and write it to a file (be sure to convert it to a string format)
                                        alterSchedPrinter.println(schedule.get(i).toString());
                                    }
                                    alterSchedPrinter.close();
                                }
                                /**
                                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                                 * a problem with the disk drive itself
                                 */
                                catch(IOException e)
                                {
                                    System.out.println("I/O Error");
                                }
                            }
                        }
                    });
                    
                    buttonPanel2.add(removeClass);
                    //call the ActionListener interface with an abstract class
                    removeClass.addActionListener(new ActionListener()
                    {
                        public void actionPerformed(ActionEvent exit)
                        {
                            //if/else statement to catch if the student has 3 classes.  If so, then the student can't remove a class, since they need a minimum of 3 classes
                            if(schedule.size() == 3)
                            {
                                /** use JOPtionPane Error Message to show student that they have too few classes
                                 * (null, "text to show", "title of Pane", type of pane)
                                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                                 * set editable, opaque, text, and font to make it easy to read
                                 * @method setEditable makes it so the user can't edit it
                                 * @method setOpague(false) sets the background of the text area to clear
                                 * @method setText adds text output to the text area
                                 * @method setFont sets the font of the text area
                                 */
                                JTextArea outputText = new JTextArea();
                                outputText.setEditable(false);
                                outputText.setOpaque(false);
                                outputText.setText("You currently have 3 classes, you can't have any less. ");
                                outputText.setFont(outputText.getFont().deriveFont(20f));
                                
                                JOptionPane.showMessageDialog(null, outputText, "Alert!", JOptionPane.ERROR_MESSAGE);
                            }
                            else
                            {
                                /**
                                 * A for loop to output the student's current schedule and show a corresponding number next to each class.  The number represents the 
                                 * class's position in the arraylist schedule.  The class and its number are added to the string output.
                                 */
                                String output = "";
                                for(int i = 0; i < schedule.size(); i++)
                                {
                                    //string list to get the classes in the arraylist schedule
                                    String list = schedule.get(i).toString();
                                    //string output to add the class gotten from list and the class's corresponding number
                                    output += list + " [" + i + "]" + "\n";       
                                }                            
                                /**
                                 * create an int value, and create a new JOptionPane to take input.  
                                 *          (value to print + "text to print")
                                 * Parse the input to an integer, then use the input to remove the corresponding 
                                 * class from the arraylist schedule
                                 * 
                                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                                 * set editable, opaque, text, and font to make it easy to read
                                 * @method setEditable makes it so the user can't edit it
                                 * @method setOpague(false) sets the background of the text area to clear
                                 * @method setText adds text output to the text area
                                 * @method setFont sets the font of the text area
                                 */
                                JTextArea outputText = new JTextArea();
                                outputText.setEditable(false);
                                outputText.setOpaque(false);
                                outputText.setText(output + "\n" + "The list above shows your schedule. " + "\n" +
                                "Please enter the number corresponding to a class to remove that class from your schedule." + "\n" 
                                + "Changes to schedule will automatically be saved. ");
                                outputText.setFont(outputText.getFont().deriveFont(20f));
                                
                                int answer = Integer.parseInt(JOptionPane.showInputDialog(outputText));
                                schedule.remove(answer);
                                try
                                {
                                    /**
                                     * Here, we read in each element from the ArrayList, which has been updated with the removed class, and write each element into the file
                                     * mySchedule.txt.  Since a previous file of the same name exists, this new one will replace it, effectively updating the file.
                                     * Be sure to close the printwriter object outside of the for loop.
                                     */
                                    //Create a filewriter object to create a file to write text to a file
                                    FileWriter alterSchedule = new FileWriter("mySchedule.txt");
                                    //create a printwriter object to actually write text to the file
                                    PrintWriter alterSchedPrinter = new PrintWriter(alterSchedule);
                                    for(int i = 0; i < schedule.size(); i++)
                                    {
                                        //iterate over each element of the array and write it to a file (be sure to convert it to a string format)
                                        alterSchedPrinter.println(schedule.get(i).toString());
                                    }
                                    alterSchedPrinter.close();
                                }
                                /**
                                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                                 * a problem with the disk drive itself
                                 */
                                catch(IOException e)
                                {
                                    System.out.println("I/O Error");
                                }
                            }
                        }
                    });
                    
                    buttonPanel2.add(closeAddRemove);
                    //call the ActionListener interface with an abstract class
                    closeAddRemove.addActionListener(new ActionListener()
                    {
                        public void actionPerformed(ActionEvent exit)
                        {
                            //when the button is pressed and ActionListener called, remove all the button added to the JPanel when alterClasses button was pressed
                            buttonPanel2.remove(addClass);
                            buttonPanel2.remove(removeClass);
                            buttonPanel2.remove(closeAddRemove);
                            
                            //revalidate and repaint the JPanel and the frame to wipe away spaces left over when the buttons were removed, so white space isn't created
                            buttonPanel2.revalidate();
                            buttonPanel2.repaint();
                            studentFrame.remove(buttonPanel2);
                            studentFrame.revalidate();
                            studentFrame.repaint();
                        }
                    });
                }
                else
                {
                    /** use JOPtionPane Error Message to show student has not paid their fees, so they can't register
                     * (null, "text to show", "title of Pane", type of pane)
                     * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                     * set editable, opaque, text, and font to make it easy to read
                     * @method setEditable makes it so the user can't edit it
                     * @method setOpague(false) sets the background of the text area to clear
                     * @method setText adds text output to the text area
                     * @method setFont sets the font of the text area
                     */
                    JTextArea outputText = new JTextArea();
                    outputText.setEditable(false);
                    outputText.setOpaque(false);
                    outputText.setText("You currently have unpaid fees, therefore you cannot register for any classes. ");
                    outputText.setFont(outputText.getFont().deriveFont(20f));
                        
                    JOptionPane.showMessageDialog(null, outputText, "Alert!", JOptionPane.ERROR_MESSAGE);
                }
                
                //add any remaining buttons and set the JPanel visibility to true, size to whatever you want it to be, and add the JPanel to the frame
                buttonPanel2.setLayout(new GridLayout(2, 2));
                buttonPanel2.setVisible(true);
                studentFrame.add(buttonPanel2);
                studentFrame.pack();
            }
        });
        
        /**
         * Courses for departments code
         * 
         * Create a JButton to show available courses per department
         * Create two ArrayLists to hold names of departments and courses
         * Add values to both arraylists
         */
        JButton depmtCourses = new JButton("Available Courses");
        //set the text font and size of the button to one that's easy to read
        depmtCourses.setFont(new Font("Arial", Font.PLAIN, 25));
        
        ArrayList<String> departments = new ArrayList<String>();
        ArrayList<String> courses = new ArrayList<String>();
        
        /**
         * Try and catch block, necessary when reading/writing I/O to and from a file
         * Use for departments arrayList
         */
        try
        {
            //Create a filewriter object to create a file to write text to a file
            FileWriter departmentList = new FileWriter("SchoolDepartments.txt");
            //create a printwriter object to actually write text to the file
            PrintWriter departmentPrinter = new PrintWriter(departmentList);
            
            /**
             * Print text to the file using different println statements
             * to separate text as different lines in the file.
             * Finish with printer.close() to close the file so file will be
             * readable
             */
            departmentPrinter.println("Computer Science");
            departmentPrinter.println("Mathematics");
            departmentPrinter.println("English");
            departmentPrinter.println("Art");
            departmentPrinter.close();
            
            try
            {   
                /**
                 * Call the filereader class and create an object to read from the file
                 * Create an object of bufferedReader type that actually reads the text from the file
                 * Create a variable for holding each line of text read from the file
                 */
                
                FileReader reader2 = new FileReader("SchoolDepartments.txt");
                BufferedReader bufReader2 = new BufferedReader(reader2);
                String line2;
                /**
                 * A while loop for reading each line of text in the file myClasses.txt
                 * Condition for while loop sets the null string to what the bufferedReader object
                 * read in the previous line from the file.  While loop continues to add lines
                 * to the arraylist so long as the line isnt empty (or null).
                 */
                while((line2 = bufReader2.readLine()) != null)
                {
                    departments.add(line2);
                }
                //close the bufferedReader object so the file will be readable.
                bufReader2.close();
            }
            /**
             * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
             * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
             * a problem with the disk drive itself
             */
            catch(IOException e)
            {       
                System.out.println("I/O Error");
            }
        }
        /**
         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
         * a problem with the disk drive itself
         */
        catch(IOException e)
        {
            System.out.println("I/O Error");
        }
        
        /**
         * Try and catch block, necessary when reading/writing I/O to and from a file
         * Use for courses arrayList
         */
        try
        {
            //Create a filewriter object to create a file to write text to a file
            FileWriter coursesList = new FileWriter("DeptCourses.txt");
            //create a printwriter object to actually write text to the file
            PrintWriter coursesPrinter = new PrintWriter(coursesList);
            
            /**
             * Print text to the file using different println statements
             * to separate text as different lines in the file.
             * Finish with printer.close() to close the file so file will be
             * readable
             */
            coursesPrinter.println("CPSC 1000");
            coursesPrinter.println("CPSC 1100");
            coursesPrinter.println("CPSC 1200");
            coursesPrinter.println("Statistics");
            coursesPrinter.println("Calculus");
            coursesPrinter.println("Algebra");
            coursesPrinter.println("English 1010");
            coursesPrinter.println("English 1020");
            coursesPrinter.println("English 2000");
            coursesPrinter.println("Art History");
            coursesPrinter.println("Why Art is Dumb");
            coursesPrinter.println("Art Practice");
            coursesPrinter.close();
            
            try
            {   
                /**
                 * Call the filereader class and create an object to read from the file
                 * Create an object of bufferedReader type that actually reads the text from the file
                 * Create a variable for holding each line of text read from the file
                 */
                
                FileReader reader3 = new FileReader("DeptCourses.txt");
                BufferedReader bufReader3 = new BufferedReader(reader3);
                String line3;
                /**
                 * A while loop for reading each line of text in the file myClasses.txt
                 * Condition for while loop sets the null string to what the bufferedReader object
                 * read in the previous line from the file.  While loop continues to add lines
                 * to the arraylist so long as the line isnt empty (or null).
                 */
                while((line3 = bufReader3.readLine()) != null)
                {
                    courses.add(line3);
                }
                //close the bufferedReader object so the file will be readable.
                bufReader3.close();
            }
            /**
             * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
             * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
             * a problem with the disk drive itself
             */
            catch(IOException e)
            {       
                System.out.println("I/O Error");
            }
        }
        /**
         * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
         * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
         * a problem with the disk drive itself
         */
        catch(IOException e)
        {
            System.out.println("I/O Error");
        }
        
        //call the ActionListener interface with an abstract class
        depmtCourses.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                /**
                 * Create a string output with initial value to "" and an int value with initial value of 0
                 * The for loop is used to go through the departments arraylist and add the department values to the string output
                 * The int value is used to iterate over the courses arraylist to print the three courses that correspond to each department (3 courses per department)
                 * Through each iteration, one of the departments is added to the output, and three of the courses for that department are added to the output.
                 * the int value is then iterated by 3 at the end of the loop to go over the next three values for the next department, and so on.  Until the loop ends
                 * Then, use a JOptionPane to show a message to the user
                 *          .showMessageDialog(frame, what to print, "frame title", type of frame)
                 */
                
                String output = "";
                int o = 0;
                for(int i = 0; i < departments.size(); i++)
                {
                    output += departments.get(i) + "\n";
                    output += courses.get(o) + "\n" + courses.get(o + 1) + "\n" + courses.get(o + 2) + "\n";
                    output += "\n";
                    
                    o += 3;
                }                        
                /**
                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                 * set editable, opaque, text, and font to make it easy to read
                 * @method setEditable makes it so the user can't edit it
                 * @method setOpague(false) sets the background of the text area to clear
                 * @method setText adds text output to the text area
                 * @method setFont sets the font of the text area
                 */
                JTextArea outputText = new JTextArea();
                outputText.setEditable(false);
                outputText.setOpaque(false);
                outputText.setText(output);
                outputText.setFont(outputText.getFont().deriveFont(20f));
                
                JOptionPane.showMessageDialog(studentFrame, outputText, "Available Courses", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        /**
         * Print Schedule button
         * 
         * This button prints the schedule
         * Create a button, call the actionlistener interface with an abstract class
         */
        JButton printSch = new JButton("Print Schedule");
        //set the text font and size of the button to one that's easy to read
        printSch.setFont(new Font("Arial", Font.PLAIN, 25));
        
        printSch.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                try
                {   
                    /**
                     * Call the filereader class and create an object to read from the file
                     * Create an object of bufferedReader type that actually reads the text from the file
                     * Create a variable for holding each line of text read from the file
                     */
                    
                    FileReader schedReader = new FileReader("mySchedule.txt");
                    BufferedReader schedBuffer = new BufferedReader(schedReader);
                    String schedLine;
                    /**
                     * A while loop for reading each line of text in the file myClasses.txt
                     * Condition for while loop sets the null string to what the bufferedReader object
                     * read in the previous line from the file.  While loop continues to print lines until
                     * schedLine is null (is empty).
                     */
                    while((schedLine = schedBuffer.readLine()) != null)
                    {
                        System.out.println(schedLine);
                    }
                    //close the bufferedReader object so the file will be readable.
                    schedBuffer.close();
                }
                /**
                 * Catch statement for I/O exceptions as to avoid the program crashing should an I/O exception occur
                 * @catch I/O exception will catch the acception if writing to a drive that doesn't exist or there's 
                 * a problem with the disk drive itself
                 */
                catch(IOException e)
                {       
                    System.out.println("I/O Error");
                }
                /**
                 * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                 * set editable, opaque, text, and font to make it easy to read
                 * @method setEditable makes it so the user can't edit it
                 * @method setOpague(false) sets the background of the text area to clear
                 * @method setText adds text output to the text area
                 * @method setFont sets the font of the text area
                 */
                JTextArea outputText = new JTextArea();
                outputText.setEditable(false);
                outputText.setOpaque(false);
                outputText.setText("Your schedule was printed to a different window ");
                outputText.setFont(outputText.getFont().deriveFont(20f));
                
                JOptionPane.showMessageDialog(studentFrame, outputText, "Schedule Printed", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        /**
         * set the layout of the frame
         * Then, add each part of the frame (buttons and text)
         */
        studentFrame.setLayout(new GridLayout(10, 1));
        studentFrame.add(depmtCourses);
        studentFrame.add(printSch);
        studentFrame.add(logout);
        
        /**
         * @method setDefaultCloseOperation(), used to close the program if the window of the program is closed, so as to avoid the program continuing to run after user closes the window
         * use the pack() to set the size of the frame to fit all of its contents
         * then, set the frame to visible
         */
        studentFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        studentFrame.pack();
        studentFrame.setVisible(true);
    }
}

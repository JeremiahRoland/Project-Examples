
/**
 * The sole purpose of this class is to run the login frame when the program is activated\
 * Jeremiah Roland
 * 10/24/16
 */
public class Homework7
{
    public static void main (String[] args)
    {
        //Make a new LoginFrame and call the run method to start the frame
        LoginFrame myLogin = new LoginFrame();
        myLogin.run();
    }
}

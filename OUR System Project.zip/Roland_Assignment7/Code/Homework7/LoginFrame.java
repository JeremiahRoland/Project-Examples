import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * A login frame representing a login interface.  Allows user to enter credentials to login the system
 * login button currently does nothing as coding hasn't been learned yet
 * Jeremiah Roland
 * 10/24/17
 */
public class LoginFrame  
{
    /**
     * Create a constructor to make the login frame.  This is done so other frames can open this login frame when the appropriate logout button is clicked
     * Constructs a new frame that is initially invisible.
     * Throws a HeadlessException
     */
    public LoginFrame() throws HeadlessException 
    {
    }
    /**
     * A run() method to run the login frame
     * Is called by other frames when the logout button is clicked
     */
    public void run()
    {
        //create the frame
        JFrame loginFrame = new JFrame("Login");
        
        //create two buttons, login and cancel, with appropriate names
        JButton login = new JButton("Login");
        JButton cancel = new JButton("Cancel");
        //set the text size and font of the buttons to something easier to read
        login.setFont(new Font("Arial", Font.PLAIN, 15));
        cancel.setFont(new Font("Arial", Font.PLAIN, 15));
        /**
         * When the cancel button is clicked, have the program closed.  
         * Do this by adding an action listener and use an anonymous class to implement the ActionListener interface.  
         * Have the method actionPerformed() called and set what needs to be done in the method.  For this, simply dispose of the frame.
         * @param the implicit parameter of this type of call is the button it is asociated with (the cancel button)
         */
        cancel.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                loginFrame.dispose();
            }
        });
        
        //declare a final variable to be used for the width of the textFields
        final int FIELD_WIDTH = 25;
        /**
         * Create two textField objects, one for username and one for password.  Set the text within these fields to the appropirate name.  Set text size to something easy to read
         * @param FIELD_WIDTH  width of the textField 
         * Create a text area to hold information regarding passwords and usernames.  
         * Set this to be unable to be edited by user. Set font to something easy to read.
         */
        JTextArea info = new JTextArea(5, 10);
        info.setText("For Student Access: " + "\n" + "Username: student" + "\n" + "Password: student" + "\n" + "\n" 
                     + "___________________"  + "\n"
                     + "For Instructor Access: " + "\n" + "Username: teacher" + "\n" + "Password: teacher" + "\n" + "\n"
                     + "___________________" + "\n"
                     + "For Department Staff Access: " + "\n" + "Username: departmentStaff" + "\n" + "Password: departmentStaff");
        info.setEditable(false);
        info.setFont(info.getFont().deriveFont(25f));
        
        /**
         * Call the addMouseListener() method when the textbox is clicked to clear the text within the box.  Use this for both the password and username boxes
         * For the password box, create a JPasswordField instead of a JTextField.  The declaration is similar, but the text within the box is hidden by dots, to emulate
         * how a real password box would look like
         */
        JTextField username = new JTextField(FIELD_WIDTH);
        username.setText("Username");
        username.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent e){
                username.setText("");
            }
        });
        
        JPasswordField password = new JPasswordField(FIELD_WIDTH);
        password.setText("Password");
        password.addMouseListener(new MouseAdapter()
        {
            @Override
            public void mouseClicked(MouseEvent e){
                password.setText("");
            }
        });
        
        username.setFont(username.getFont().deriveFont(25f));
        password.setFont(password.getFont().deriveFont(25f));
        
        /**
         * When the login button is clicked, have the program load another frame based on username and password  
         * Do this by adding an action listener and use an anonymous class to implement the ActionListener interface.  
         * Have the method actionPerformed() called and set what needs to be done in the method.  For this, simply load the appropriate frame.
         * @param the implicit parameter of this type of call is the button it is asociated with (the login button)
         */
        login.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent exit)
            {
                /**
                 * Have a series of if/else statements to check for what the username and password entered are
                 * Use the getText() method on the text fields for username and password and assign them to their respective string values
                 * Use these string values for testing what the contents of the text fields are
                 * If they are "student", then create a student frame object, run the frame using the run() method, and dispose of the login frame.
                 * Repeat this process for each of the additional frames in the program
                 */
                
                String usernameText = username.getText();
                String passwordText = password.getText();
                if(usernameText.equals("student") && passwordText.equals("student"))
                {
                    StudentFrame myStudent = new StudentFrame();
                    myStudent.run();
                    loginFrame.dispose();
                }
                else if(usernameText.equals("teacher") && passwordText.equals("teacher"))
                {
                    InstructorFrame myInstructor = new InstructorFrame();
                    myInstructor.run();
                    loginFrame.dispose();
                }
                else if(usernameText.equals("departmentStaff") && passwordText.equals("departmentStaff"))
                {
                    DepartmentStaffFrame myStaff = new DepartmentStaffFrame();
                    myStaff.run();
                    loginFrame.dispose();
                }
                else
                {
                    /**
                     * Create a JTextArea to display text so it is easier to read than the default text size for the JOptionPane
                     * set editable, opaque, text, and font to make it easy to read
                     * @method setEditable makes it so the user can't edit it
                     * @method setOpague(false) sets the background of the text area to clear
                     * @method setText adds text output to the text area
                     * @method setFont sets the font of the text area
                     */
                    JTextArea outputText = new JTextArea();
                    outputText.setEditable(false);
                    outputText.setOpaque(false);
                    outputText.setText("Incorrect Username and/or Password.");
                    outputText.setFont(outputText.getFont().deriveFont(20f));
                    
                    JOptionPane.showMessageDialog(null, outputText, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        /**
         * Set the layout of the frame to GridLayoug(rows, columns). This style is chosen simply for organizational reasons
         * Then, add each part of the frame (buttons and text)
         */
        //loginFrame.setLayout(new GridLayout(15, 2));
        loginFrame.setLayout(new FlowLayout());
        
        loginFrame.add(username);
        loginFrame.add(password);
        loginFrame.add(login);
        loginFrame.add(cancel);
        loginFrame.add(info);
        /**
         * @method setDefaultCloseOperation(), used to close the program if the window of the program is closed, so as to avoid the program continuing to run after user closes the window
         * use the pack() to set the size of the frame to fit all of its contents
         * then, set the frame to visible
         */
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.pack();
        loginFrame.setVisible(true);
    }
}